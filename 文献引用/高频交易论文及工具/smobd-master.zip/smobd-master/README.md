# smobd
Replication of A Stochastic Model for Order Book Dynamics by Cont, Stoikov, and Talreja, 2010
